//
// Created by nhchung on 23/03/2023.
//

#ifndef UTILS_H
#define UTILS_H
#define MAX_LINE 512
#define MAX_LENGTH 256
#define MAX_FILENAME_LENGTH 1024
#define MAX_VIOLATION_CAT_NAME_LENGTH 128
#define DIGEST_SIZE 32
#define ENV_ZSYS_THREAD_NAME_PREFIX_STR "ZSYS_THREAD_NAME_PREFIX_STR=MSEC"

typedef struct dylib_hash{
    char* dylib_name;
    char* dylib_text_section_sha256_hex;
//    char* dylib_text_section_md5_hex;
} dylib_hash_t;
// hashes funcs
int util_get_str_hcs_hash(char *s);
int util_get_mem_hcs_hash(char *mem, int len);
int util_get_char_shift_left(char a, int count);
int util_get_ssl_certificate_info(const char* host, const char* port, const int timeout_ms,
                                       char** cert_in_pem, char** cert_subject_key_id,
                                       char** cert_authority_key_id, char** cert_fingerprint);
int util_get_msec_violation_category_type(char* violation_category_name);
char* util_get_msec_violation_get_category_name(int violation_category_type);
char* util_get_msec_otp_code(char* session_key, int32_t hotp_counter, int64_t timestamp);
char* util_get_msec_otp_code_test(void);
dylib_hash_t*  util_get_dylib_text_section_sha256(char** p_dylib_hash_name_list, int dylib_hash_list_len);
void util_free_dylib_hash_list(dylib_hash_t* p_dylib_hash_list);
void util_run_test_dylib(void);
void util_run_tests(void );
#endif //UTILS_H
